/**
 * Background service worker for the ANVISA Auto-Fill extension.
 * Manages the badge icon to indicate data status.
 */

/**
 * Count the number of filled fields in the data object.
 * Only counts known ANVISA form fields (not arbitrary keys).
 */
var KNOWN_FIELDS = [
  'requesterRg', 'requesterAddress', 'requesterCep', 'requesterPhone', 'requesterLandline',
  'patientName', 'patientRg', 'patientCpf', 'patientDob', 'patientCep',
  'patientAddress', 'patientState', 'patientCity', 'patientPhone', 'patientEmail',
  'doctorName', 'doctorCrm', 'doctorSpecialty', 'doctorUf', 'doctorCity',
  'doctorPhone', 'doctorMobile', 'doctorEmail', 'prescriptionDate'
];

function countFilledFields(data) {
  if (!data || typeof data !== 'object') return 0;
  var count = 0;
  for (var i = 0; i < KNOWN_FIELDS.length; i++) {
    var key = KNOWN_FIELDS[i];
    if (data[key] && typeof data[key] === 'string' && data[key].trim().length > 0) {
      count++;
    }
  }
  // Also count file entries
  if (data._files && Array.isArray(data._files)) {
    count += data._files.length;
  }
  return count;
}

/**
 * Update the badge to show the number of filled fields.
 */
function updateBadgeFromStorage() {
  chrome.storage.local.get(['anvisaFormData'], function (result) {
    if (result.anvisaFormData) {
      var count = countFilledFields(result.anvisaFormData);
      chrome.action.setBadgeText({ text: String(count) });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  });
}

// Update badge when data is stored/cleared
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'data-updated') {
    var count = message.fieldCount || 0;
    chrome.action.setBadgeText({ text: String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    sendResponse({ success: true });
  }

  if (message.action === 'data-cleared') {
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ success: true });
  }

  // Fetch a file from a URL (used by content script for Firebase Storage files)
  if (message.action === 'fetch-file') {
    var url = message.url;
    var fileName = message.fileName || 'file';

    fetch(url)
      .then(function (response) {
        if (!response.ok) throw new Error('HTTP ' + response.status + ' ' + response.statusText);
        return response.blob();
      })
      .then(function (blob) {
        return new Promise(function (resolve) {
          var reader = new FileReader();
          reader.onloadend = function () {
            resolve({
              success: true,
              data: reader.result,   // data:...;base64,... string
              type: blob.type,
              size: blob.size,
              fileName: fileName,
            });
          };
          reader.onerror = function () {
            resolve({ success: false, error: 'Erro ao ler arquivo' });
          };
          reader.readAsDataURL(blob);
        });
      })
      .then(sendResponse)
      .catch(function (err) {
        console.error('[ANVISA BG] File fetch error:', err);
        sendResponse({ success: false, error: err.message });
      });

    return true; // Async response
  }
});

// On install/update, sync badge from storage
chrome.runtime.onInstalled.addListener(function () {
  updateBadgeFromStorage();
});

// On startup, sync badge from storage
chrome.runtime.onStartup.addListener(function () {
  updateBadgeFromStorage();
});
