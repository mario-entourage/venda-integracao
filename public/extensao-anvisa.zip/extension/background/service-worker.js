/**
 * Background service worker for the ANVISA Auto-Fill extension.
 * Manages the badge icon to indicate data status.
 */

/**
 * Count the number of filled fields in the data object.
 * Only counts known ANVISA form fields (not arbitrary keys).
 */
var KNOWN_FIELDS = [
  'requesterRg', 'requesterAddress', 'requesterCep', 'requesterPhone', 'requesterLandline',
  'patientName', 'patientRg', 'patientCpf', 'patientDob', 'patientCep',
  'patientAddress', 'patientState', 'patientCity', 'patientPhone', 'patientEmail',
  'doctorName', 'doctorCrm', 'doctorSpecialty', 'doctorUf', 'doctorCity',
  'doctorPhone', 'doctorMobile', 'doctorEmail', 'prescriptionDate'
];

function countFilledFields(data) {
  if (!data || typeof data !== 'object') return 0;
  var count = 0;
  for (var i = 0; i < KNOWN_FIELDS.length; i++) {
    var key = KNOWN_FIELDS[i];
    if (data[key] && typeof data[key] === 'string' && data[key].trim().length > 0) {
      count++;
    }
  }
  return count;
}

/**
 * Update the badge to show the number of filled fields.
 */
function updateBadgeFromStorage() {
  chrome.storage.local.get(['anvisaFormData'], function (result) {
    if (result.anvisaFormData) {
      var count = countFilledFields(result.anvisaFormData);
      chrome.action.setBadgeText({ text: String(count) });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  });
}

// Update badge when data is stored/cleared
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'data-updated') {
    var count = message.fieldCount || 0;
    chrome.action.setBadgeText({ text: String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    sendResponse({ success: true });
  }

  if (message.action === 'data-cleared') {
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ success: true });
  }
});

// On install/update, sync badge from storage
chrome.runtime.onInstalled.addListener(function () {
  updateBadgeFromStorage();
});

// On startup, sync badge from storage
chrome.runtime.onStartup.addListener(function () {
  updateBadgeFromStorage();
});
