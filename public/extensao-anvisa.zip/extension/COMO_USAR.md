# ANVISA Auto-Fill — Guia de Instalacao e Uso

## Instalacao (uma vez so)

1. Baixe a pasta `extension` do Google Drive:
   https://drive.google.com/drive/folders/1DNNFn6-zctG0pQUcPDeLokeKnoad7i48?usp=drive_link

2. Abra o navegador:
   - **Chrome**: digite `chrome://extensions` na barra de endereco
   - **Edge**: digite `edge://extensions` na barra de endereco

3. Ative o **Modo de desenvolvedor** (canto superior direito)

4. Clique em **"Carregar sem compactacao"** (ou "Load unpacked")

5. Selecione a pasta `extension` que voce baixou

6. Pronto — o icone **"A"** azul aparece na barra do navegador

> A extensao fica instalada mesmo depois de fechar o navegador. So precisa fazer isso uma vez.

---

## Uso no dia a dia

1. No app, preencha seu perfil de solicitante (menu lateral > Perfil)
2. Crie uma nova solicitacao e envie os documentos (arraste ou clique na area de upload)
3. Clique em **"Preencher ANVISA"** quando os tres tipos estiverem cobertos
4. Aguarde o processamento — os dados sao enviados automaticamente para a extensao
5. O icone da extensao mostra um **numero** (ex: "14") indicando os campos prontos
6. Clique em **"Abrir site da ANVISA"** (abre em nova aba)
7. Na aba da ANVISA, clique no icone da extensao e depois em **"Preencher Formulario"**
8. Os campos sao preenchidos automaticamente — confira e submeta
9. Volte ao app e insira o numero de confirmacao para finalizar

---

## Duvidas

- **O icone nao aparece?** Clique no icone de quebra-cabeca na barra do navegador e fixe a extensao.
- **O botao "Preencher" esta desativado?** Voce precisa estar na pagina da ANVISA (`solicitacao.servicos.gov.br`).
- **Campos nao foram preenchidos?** Alguns campos podem ter nomes diferentes no formulario. Preencha manualmente os que faltarem.
- **Extensao nao respondeu?** Recarregue a pagina do aplicativo (F5) e tente novamente.
