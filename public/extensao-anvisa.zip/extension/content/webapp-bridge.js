/**
 * Content script injected on the web app pages.
 * Bridges data from the React app to the Chrome extension via chrome.storage.local.
 *
 * IMPORTANT: Content scripts run in an "isolated world" — they share the DOM with the
 * page but NOT the JavaScript context. This means:
 *   - CustomEvent.detail is null when dispatched from page context to content script
 *   - window properties set here are invisible to the page
 *
 * Solution: Use window.postMessage for cross-world communication.
 * The page dispatches postMessage → content script receives it via 'message' listener.
 */
(function () {
  'use strict';

  // Prevent duplicate injection
  if (window.__anvisaBridgeLoaded) return;
  window.__anvisaBridgeLoaded = true;

  /**
   * Check if the chrome extension API is still valid.
   * After extension reload/update, old content scripts lose their chrome.* context.
   */
  function isChromeApiValid() {
    try {
      return !!(chrome && chrome.storage && chrome.storage.local && chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  /**
   * Send an error back to the web app so it can show an appropriate message.
   */
  function sendError(reason) {
    window.postMessage(
      {
        type: 'anvisa-extension-data-stored',
        success: false,
        error: reason,
      },
      '*'
    );
  }

  // Signal to the web app that the extension is installed.
  window.postMessage({ type: 'anvisa-extension-ready' }, '*');

  // Listen for data sent from the React app via postMessage
  window.addEventListener('message', function (event) {
    // Only accept messages from the same origin (the web app page itself)
    if (event.origin !== window.location.origin) {
      return;
    }

    var message = event.data;
    if (!message || typeof message !== 'object') return;

    // Respond to pings from the web app (component may mount after bridge loads)
    if (message.type === 'anvisa-extension-ping') {
      window.postMessage({ type: 'anvisa-extension-ready' }, '*');
      return;
    }

    // Handle data transfer from web app
    if (message.type === 'anvisa-autofill-data') {
      var data = message.data;
      if (!data || typeof data !== 'object') {
        console.warn('[ANVISA Extension] Received invalid data:', data);
        return;
      }

      // Check if chrome API is still valid (extension may have been reloaded)
      if (!isChromeApiValid()) {
        console.warn('[ANVISA Extension] Chrome API invalidated — extension was reloaded. Please refresh this page.');
        sendError('Extensão foi atualizada. Recarregue esta página (F5) e tente novamente.');
        return;
      }

      // Store the data with a timestamp
      try {
        chrome.storage.local.set(
          {
            anvisaFormData: data,
            dataTimestamp: Date.now(),
          },
          function () {
            if (chrome.runtime.lastError) {
              console.warn('[ANVISA Extension] Storage error:', chrome.runtime.lastError.message);
              sendError('Erro ao salvar dados. Recarregue a página e tente novamente.');
              return;
            }

            // Count only non-empty known fields for accurate badge display
            var filledCount = 0;
            var totalKeys = Object.keys(data);
            for (var i = 0; i < totalKeys.length; i++) {
              var val = data[totalKeys[i]];
              if (val && typeof val === 'string' && val.trim().length > 0) {
                filledCount++;
              }
            }

            console.log('[ANVISA Extension] Data stored successfully:', filledCount, 'filled fields');

            // Notify the background service worker to update the badge with field count
            try {
              chrome.runtime.sendMessage({ action: 'data-updated', fieldCount: filledCount });
            } catch (e) {
              // Badge update is non-critical
            }

            // Send confirmation back to the web app via postMessage
            window.postMessage(
              {
                type: 'anvisa-extension-data-stored',
                success: true,
                fieldCount: filledCount,
              },
              '*'
            );
          }
        );
      } catch (e) {
        console.error('[ANVISA Extension] Failed to store data:', e);
        sendError('Erro na extensão. Recarregue esta página (F5) e tente novamente.');
      }
    }

    // Handle data clear requests from the web app
    if (message.type === 'anvisa-autofill-clear') {
      if (!isChromeApiValid()) return;
      try {
        chrome.storage.local.remove(['anvisaFormData', 'dataTimestamp'], function () {
          console.log('[ANVISA Extension] Data cleared');
          try {
            chrome.runtime.sendMessage({ action: 'data-cleared' });
          } catch (e) { /* non-critical */ }
        });
      } catch (e) {
        console.warn('[ANVISA Extension] Failed to clear data:', e);
      }
    }
  });

  console.log('[ANVISA Extension] Web app bridge loaded on:', window.location.origin);
})();
