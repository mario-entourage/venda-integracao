/**
 * Content script injected on the ANVISA gov.br form page.
 * Receives 'fill-form' messages from the popup and fills form fields
 * using data stored in chrome.storage.local.
 *
 * Depends on: lib/field-mapping.js (FIELD_MAPPING), lib/brazilian-states.js (UF_MAP)
 *
 * KEY DESIGN DECISIONS:
 *
 * 1. The ANVISA form is a React/Next.js app using the Brazil Design System (DS Gov).
 *    The DS Gov does NOT always use standard <label for="id"> + <input id="id"> patterns.
 *    Labels may be <label>, <span>, <p>, <div>, or <strong> elements.
 *    IDs are often auto-generated (e.g. "react-select-2-input") and not meaningful.
 *
 * 2. The form has TWO sections with overlapping field names:
 *      "DADOS DO SOLICITANTE" (requester) — first in DOM
 *      "DADOS DO PACIENTE"   (patient)   — second in DOM
 *    Fields like "Nome", "Data de Nascimento", "CEP", "E-mail" exist in BOTH.
 *
 * 3. Our approach: find ALL text nodes on the page that match our keywords,
 *    then locate the nearest input/select/textarea element. For patient fields,
 *    only match elements that appear AFTER the "DADOS DO PACIENTE" heading.
 *
 * 4. The script may be re-injected on demand via chrome.scripting.executeScript
 *    from the popup. Guard against duplicate listeners with a global flag.
 */
(function () {
  'use strict';

  // Prevent duplicate injection
  if (window.__anvisaFillerLoaded) {
    console.log('[ANVISA Filler] Already loaded, skipping re-initialization');
    return;
  }
  window.__anvisaFillerLoaded = true;

  // ──────────────────────────────────────────────────────
  //  DOM position utilities
  // ──────────────────────────────────────────────────────

  function isBefore(a, b) {
    return !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  // ──────────────────────────────────────────────────────
  //  Section boundary detection
  // ──────────────────────────────────────────────────────

  var _requesterHeading = null;
  var _patientHeading = null;
  var _nextSectionHeading = null;

  function findSectionBoundaries() {
    // Always re-scan (the form may have changed since last call)
    _requesterHeading = null;
    _patientHeading = null;
    _nextSectionHeading = null;

    var allElements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, legend, strong, span, p, div, label');
    var sectionHeadings = [];

    for (var i = 0; i < allElements.length; i++) {
      var el = allElements[i];
      var text = getDirectText(el).trim().toLowerCase();

      if (text.indexOf('dados do solicitante') !== -1) {
        _requesterHeading = el;
        console.log('[ANVISA Filler] Found "DADOS DO SOLICITANTE" heading:', el.tagName, el.className);
      }
      if (text.indexOf('dados do paciente') !== -1) {
        _patientHeading = el;
        console.log('[ANVISA Filler] Found "DADOS DO PACIENTE" heading:', el.tagName, el.className);
      }
      if (text.indexOf('dados do solicitante') !== -1 ||
          text.indexOf('dados do médico') !== -1 ||
          text.indexOf('dados do medico') !== -1 ||
          text.indexOf('dados da receita') !== -1 ||
          text.indexOf('dados do prescritor') !== -1 ||
          text.indexOf('informações do médico') !== -1 ||
          text.indexOf('prosseguir para passo') !== -1) {
        sectionHeadings.push(el);
      }
    }

    if (_patientHeading) {
      for (var j = 0; j < sectionHeadings.length; j++) {
        if (isBefore(_patientHeading, sectionHeadings[j])) {
          _nextSectionHeading = sectionHeadings[j];
          console.log('[ANVISA Filler] Next section after patient:', _nextSectionHeading.tagName, getDirectText(_nextSectionHeading).trim());
          break;
        }
      }
    }

    if (!_patientHeading) {
      console.warn('[ANVISA Filler] Could not find "DADOS DO PACIENTE" heading — will fill without section scoping');
    }
    if (!_requesterHeading) {
      console.warn('[ANVISA Filler] Could not find "DADOS DO SOLICITANTE" heading — requester fields will fill without section scoping');
    }
  }

  function isInRequesterSection(el) {
    if (!_requesterHeading) return true; // No section detected — allow all matches

    var afterRequesterHeading = isBefore(_requesterHeading, el);
    if (!afterRequesterHeading) return false;

    // The requester section ends where the patient section begins
    if (_patientHeading) {
      return isBefore(el, _patientHeading);
    }

    return true;
  }

  function isInPatientSection(el) {
    if (!_patientHeading) return true; // No section detected — allow all matches

    var afterPatientHeading = isBefore(_patientHeading, el);
    if (!afterPatientHeading) return false;

    if (_nextSectionHeading) {
      return isBefore(el, _nextSectionHeading);
    }

    return true;
  }

  function getDirectText(el) {
    var text = '';
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === Node.TEXT_NODE) {
        text += el.childNodes[i].textContent;
      }
    }
    return text;
  }

  // ──────────────────────────────────────────────────────
  //  Value setters (React/Angular compatible)
  // ──────────────────────────────────────────────────────

  function setInputValue(element, value) {
    if (!element || !value) return false;

    var tagName = element.tagName.toLowerCase();

    if (tagName === 'select') {
      return setSelectValue(element, value);
    }

    if (tagName === 'textarea') {
      return setValueWithNativeSetter(element, value, window.HTMLTextAreaElement);
    }

    return setValueWithNativeSetter(element, value, window.HTMLInputElement);
  }

  function setValueWithNativeSetter(element, value, prototypeObj) {
    try {
      var nativeSetter = Object.getOwnPropertyDescriptor(prototypeObj.prototype, 'value');
      if (nativeSetter && nativeSetter.set) {
        nativeSetter.set.call(element, value);
      } else {
        element.value = value;
      }

      element.focus();
      element.dispatchEvent(new Event('focus', { bubbles: true }));
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      element.dispatchEvent(new Event('blur', { bubbles: true }));

      return true;
    } catch (e) {
      console.warn('[ANVISA Filler] Error setting value:', e);
      return false;
    }
  }

  function setSelectValue(selectEl, value) {
    if (!selectEl || !value) return false;

    var options = selectEl.querySelectorAll('option');
    var found = false;
    var valueLower = value.toLowerCase().trim();

    var fullStateName = (typeof UF_MAP !== 'undefined' && UF_MAP[value.toUpperCase()]) || '';
    var fullStateNameLower = fullStateName.toLowerCase();

    for (var i = 0; i < options.length; i++) {
      var optValue = (options[i].value || '').toLowerCase().trim();
      var optText = (options[i].textContent || '').toLowerCase().trim();

      if (
        optValue === valueLower ||
        optText === valueLower ||
        optValue === fullStateNameLower ||
        optText === fullStateNameLower ||
        optText.indexOf(valueLower) !== -1 ||
        (fullStateNameLower && optText.indexOf(fullStateNameLower) !== -1)
      ) {
        selectEl.value = options[i].value;
        selectEl.selectedIndex = i;
        found = true;
        break;
      }
    }

    if (found) {
      selectEl.dispatchEvent(new Event('change', { bubbles: true }));
      selectEl.dispatchEvent(new Event('input', { bubbles: true }));
    }

    return found;
  }

  // ──────────────────────────────────────────────────────
  //  Element finders - Multi-strategy approach
  // ──────────────────────────────────────────────────────

  function getInputNear(textElement, inputType) {
    if (!textElement) return null;

    var selector = 'input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), select, textarea';
    if (inputType === 'select') selector = 'select';
    else if (inputType === 'textarea') selector = 'textarea';
    else if (inputType === 'input') selector = 'input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"])';

    // Strategy 1: Standard <label for="id">
    if (textElement.tagName === 'LABEL' && textElement.htmlFor) {
      var el = document.getElementById(textElement.htmlFor);
      if (el) return el;
    }

    // Strategy 2: Input inside the text element
    var childInput = textElement.querySelector(selector);
    if (childInput) return childInput;

    // Strategy 3: Walk through next siblings
    var sib = textElement.nextElementSibling;
    for (var sibCount = 0; sib && sibCount < 5; sibCount++) {
      if (sib.matches && sib.matches(selector)) return sib;
      var sibInput = sib.querySelector(selector);
      if (sibInput) return sibInput;
      sib = sib.nextElementSibling;
    }

    // Strategy 4: Walk UP the DOM tree (up to 8 levels)
    var ancestor = textElement.parentElement;
    for (var level = 0; ancestor && level < 8; level++) {
      var tag = ancestor.tagName.toLowerCase();
      if (tag === 'body' || tag === 'form' || tag === 'main') break;

      var allInputsInAncestor = ancestor.querySelectorAll(selector);
      if (allInputsInAncestor.length === 1) {
        return allInputsInAncestor[0];
      }
      if (allInputsInAncestor.length > 1) {
        // Return the first one that comes AFTER the text element
        for (var ai = 0; ai < allInputsInAncestor.length; ai++) {
          if (isBefore(textElement, allInputsInAncestor[ai])) {
            return allInputsInAncestor[ai];
          }
        }
      }

      // Check ancestor's next siblings
      var nextAncestorSib = ancestor.nextElementSibling;
      for (var ns = 0; nextAncestorSib && ns < 3; ns++) {
        if (nextAncestorSib.matches && nextAncestorSib.matches(selector)) return nextAncestorSib;
        var nasInput = nextAncestorSib.querySelector(selector);
        if (nasInput) return nasInput;
        nextAncestorSib = nextAncestorSib.nextElementSibling;
      }

      ancestor = ancestor.parentElement;
    }

    return null;
  }

  function findTextElements(keyword) {
    var results = [];
    var keywordLower = keyword.toLowerCase();

    var candidates = document.querySelectorAll('label, span, p, div, strong, legend, h1, h2, h3, h4, h5, h6, td, th, a');

    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      var text = (el.textContent || '').toLowerCase().trim();

      if (text.indexOf(keywordLower) !== -1 && text.length < 300) {
        results.push({ element: el, text: text, length: text.length });
      }
    }

    results.sort(function (a, b) { return a.length - b.length; });
    return results;
  }

  /**
   * Determine the section check function for a given mapping.
   * Returns { needsBoundaries, sectionCheck } where sectionCheck(el) returns
   * true if the element is in the correct section (or no section constraint).
   */
  function getSectionChecker(mapping) {
    var section = mapping.section;
    if (section === 'patient') {
      return { needsBoundaries: true, check: function (el) { return !_patientHeading || isInPatientSection(el); } };
    }
    if (section === 'requester') {
      return { needsBoundaries: true, check: function (el) { return !_requesterHeading || isInRequesterSection(el); } };
    }
    return { needsBoundaries: false, check: function () { return true; } };
  }

  function findElement(mapping) {
    var sectionInfo = getSectionChecker(mapping);

    if (sectionInfo.needsBoundaries) {
      findSectionBoundaries();
    }

    // Strategy A: Label keyword matching
    for (var k = 0; k < mapping.labelKeywords.length; k++) {
      var keyword = mapping.labelKeywords[k];
      var textElements = findTextElements(keyword);

      for (var t = 0; t < textElements.length; t++) {
        var textEl = textElements[t].element;

        if (!sectionInfo.check(textEl)) continue;

        var inputEl = getInputNear(textEl, mapping.inputType);
        if (inputEl) {
          // Also verify the input is in the correct section
          if (!sectionInfo.check(inputEl)) continue;

          console.log('[ANVISA Filler] Found', mapping.dataKey, 'via label "' + keyword + '"',
            '→', inputEl.tagName, inputEl.name || inputEl.id || '(no name/id)');
          return inputEl;
        }
      }
    }

    // Strategy B: Attribute-based search (name, id, placeholder, aria-label)
    var allInputs = document.querySelectorAll('input:not([type="hidden"]), select, textarea');

    for (var a = 0; a < mapping.inputKeywords.length; a++) {
      var attrKeyword = mapping.inputKeywords[a].toLowerCase();

      for (var i = 0; i < allInputs.length; i++) {
        var inp = allInputs[i];

        if (!sectionInfo.check(inp)) continue;

        var searchStr = [
          inp.name || '',
          inp.id || '',
          inp.placeholder || '',
          inp.getAttribute('aria-label') || '',
          inp.getAttribute('data-field') || '',
          inp.getAttribute('formcontrolname') || '',
        ].join(' ').toLowerCase();

        if (searchStr.indexOf(attrKeyword) !== -1) {
          console.log('[ANVISA Filler] Found', mapping.dataKey, 'via attr "' + attrKeyword + '"',
            '→', inp.tagName, inp.name || inp.id || '(no name/id)');
          return inp;
        }
      }
    }

    // Strategy C: Positional matching for section-scoped fields
    if (sectionInfo.needsBoundaries && (mapping.section === 'patient' ? _patientHeading : _requesterHeading)) {
      for (var lk = 0; lk < mapping.labelKeywords.length; lk++) {
        var kw = mapping.labelKeywords[lk].toLowerCase();
        var allCandidates = document.querySelectorAll('label, span, p, div, strong, legend');

        for (var c = 0; c < allCandidates.length; c++) {
          var cand = allCandidates[c];
          if (!sectionInfo.check(cand)) continue;

          var candText = (cand.textContent || '').toLowerCase().trim();
          var kwWords = kw.split(/\s+/);
          var allWordsMatch = kwWords.every(function (w) { return candText.indexOf(w) !== -1; });

          if (allWordsMatch && candText.length < 200) {
            var nearInput = getInputNear(cand, mapping.inputType);
            if (nearInput && sectionInfo.check(nearInput)) {
              console.log('[ANVISA Filler] Found', mapping.dataKey, 'via positional "' + kw + '"',
                '→', nearInput.tagName, nearInput.name || nearInput.id || '(no name/id)');
              return nearInput;
            }
          }
        }
      }
    }

    return null;
  }

  // ──────────────────────────────────────────────────────
  //  Form fill orchestration
  // ──────────────────────────────────────────────────────

  function fillForm(data) {
    var results = { filled: 0, total: 0, details: [] };

    if (typeof FIELD_MAPPING === 'undefined') {
      console.error('[ANVISA Filler] FIELD_MAPPING not loaded');
      return results;
    }

    // Reset cached section boundaries
    _requesterHeading = null;
    _patientHeading = null;
    _nextSectionHeading = null;

    // Log diagnostic info
    var inputCount = document.querySelectorAll('input:not([type="hidden"])').length;
    var selectCount = document.querySelectorAll('select').length;
    var textareaCount = document.querySelectorAll('textarea').length;
    var labelCount = document.querySelectorAll('label').length;

    console.log('[ANVISA Filler] ────────────────────────────────────');
    console.log('[ANVISA Filler] Starting fill with', Object.keys(data).length, 'data fields');
    console.log('[ANVISA Filler] Page has', inputCount, 'inputs,', selectCount, 'selects,',
      textareaCount, 'textareas,', labelCount, 'labels');

    // Log all labels for debugging
    var labels = document.querySelectorAll('label');
    for (var li = 0; li < Math.min(labels.length, 30); li++) {
      console.log('[ANVISA Filler]   Label[' + li + ']: "' +
        (labels[li].textContent || '').trim().substring(0, 100) + '"' +
        (labels[li].htmlFor ? ' (for=' + labels[li].htmlFor + ')' : ''));
    }

    // Also log all visible inputs
    var visInputs = document.querySelectorAll('input:not([type="hidden"])');
    for (var vi = 0; vi < Math.min(visInputs.length, 30); vi++) {
      console.log('[ANVISA Filler]   Input[' + vi + ']:',
        visInputs[vi].type || 'text',
        'name=' + (visInputs[vi].name || '(none)'),
        'id=' + (visInputs[vi].id || '(none)'),
        'placeholder=' + (visInputs[vi].placeholder || '(none)'));
    }

    // Check for iframes
    var iframes = document.querySelectorAll('iframe');
    if (iframes.length > 0) {
      console.log('[ANVISA Filler] Page has', iframes.length, 'iframes:');
      for (var fi = 0; fi < iframes.length; fi++) {
        console.log('[ANVISA Filler]   iframe[' + fi + ']:', iframes[fi].src || '(no src)');
      }
    }

    console.log('[ANVISA Filler] ────────────────────────────────────');

    for (var i = 0; i < FIELD_MAPPING.length; i++) {
      var mapping = FIELD_MAPPING[i];
      var value = data[mapping.dataKey];

      if (!value || (typeof value === 'string' && !value.trim())) continue;

      results.total++;

      var element = findElement(mapping);
      if (element) {
        var success = setInputValue(element, typeof value === 'string' ? value.trim() : value);
        if (success) {
          results.filled++;
          results.details.push({
            field: mapping.dataKey,
            status: 'filled',
            value: typeof value === 'string' ? value.trim() : value,
          });
        } else {
          results.details.push({
            field: mapping.dataKey,
            status: 'error',
            reason: 'Falha ao definir valor',
          });
        }
      } else {
        results.details.push({
          field: mapping.dataKey,
          status: 'not_found',
          reason: 'Campo não encontrado na página' + (mapping.section ? ' (seção: ' + mapping.section + ')' : ''),
        });
      }
    }

    return results;
  }

  // ──────────────────────────────────────────────────────
  //  Wait for form to render (React/SPA)
  // ──────────────────────────────────────────────────────

  function waitForForm(callback) {
    var MAX_WAIT_MS = 15000;
    var CHECK_INTERVAL_MS = 500;
    var elapsed = 0;

    function check() {
      var inputCount = document.querySelectorAll('input:not([type="hidden"])').length;
      var selectCount = document.querySelectorAll('select').length;
      var textareaCount = document.querySelectorAll('textarea').length;
      var total = inputCount + selectCount + textareaCount;

      console.log('[ANVISA Filler] Waiting for form... ' + (elapsed / 1000) + 's | Total form elements:', total);

      if (total >= 3) {
        console.log('[ANVISA Filler] Form detected with', total, 'elements. Proceeding to fill.');
        setTimeout(callback, 300);
        return;
      }

      elapsed += CHECK_INTERVAL_MS;
      if (elapsed >= MAX_WAIT_MS) {
        console.warn('[ANVISA Filler] Timeout waiting for form. Elements found:', total);
        console.warn('[ANVISA Filler] The form may not be on this page. Check if you need to:');
        console.warn('[ANVISA Filler]   1. Navigate to the form page (e.g., iniciar nova solicitação)');
        console.warn('[ANVISA Filler]   2. Click "Editar" or "Prosseguir" on the current process');
        console.warn('[ANVISA Filler]   3. Scroll down to reveal the form');
        callback(); // Try anyway
        return;
      }

      setTimeout(check, CHECK_INTERVAL_MS);
    }

    check();
  }

  // ──────────────────────────────────────────────────────
  //  Page diagnostic helper
  // ──────────────────────────────────────────────────────

  function getDiagnostics() {
    var inputCount = document.querySelectorAll('input:not([type="hidden"])').length;
    var selectCount = document.querySelectorAll('select').length;
    var textareaCount = document.querySelectorAll('textarea').length;
    var labelCount = document.querySelectorAll('label').length;
    var iframeCount = document.querySelectorAll('iframe').length;
    var total = inputCount + selectCount + textareaCount;

    var bodyText = (document.body.textContent || '').toLowerCase();
    var hasPaciente = bodyText.indexOf('dados do paciente') !== -1;
    var hasSolicitante = bodyText.indexOf('dados do solicitante') !== -1;
    var hasNomeCompleto = bodyText.indexOf('nome completo') !== -1;

    return {
      url: window.location.href,
      frame: window === window.top ? 'TOP' : 'IFRAME',
      inputs: inputCount,
      selects: selectCount,
      textareas: textareaCount,
      labels: labelCount,
      iframes: iframeCount,
      totalFormElements: total,
      hasFormFields: total >= 3,
      hasPacienteSection: hasPaciente,
      hasSolicitanteSection: hasSolicitante,
      hasNomeCompleto: hasNomeCompleto,
    };
  }

  // ──────────────────────────────────────────────────────
  //  Message listener
  // ──────────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === 'fill-form') {
      chrome.storage.local.get(['anvisaFormData'], function (result) {
        var data = result.anvisaFormData;

        if (!data) {
          sendResponse({
            success: false,
            error: 'Nenhum dado encontrado. Envie os dados do aplicativo primeiro.',
          });
          return;
        }

        waitForForm(function () {
          var fillResult = fillForm(data);

          console.log('[ANVISA Filler] Fill complete:', fillResult.filled, '/', fillResult.total, 'fields');

          sendResponse({
            success: true,
            filled: fillResult.filled,
            total: fillResult.total,
            details: fillResult.details,
          });
        });
      });

      return true; // Async response
    }

    if (message.action === 'check-page') {
      var diag = getDiagnostics();
      sendResponse(diag);
      return;
    }

    if (message.action === 'diagnose') {
      var diagInfo = getDiagnostics();
      console.log('[ANVISA Filler] Diagnostics:', JSON.stringify(diagInfo, null, 2));

      // Log labels
      var labels = document.querySelectorAll('label');
      var labelTexts = [];
      for (var i = 0; i < Math.min(labels.length, 30); i++) {
        labelTexts.push((labels[i].textContent || '').trim().substring(0, 80));
      }
      diagInfo.labelTexts = labelTexts;

      // Log iframes
      var iframes = document.querySelectorAll('iframe');
      var iframeSrcs = [];
      for (var fi = 0; fi < iframes.length; fi++) {
        iframeSrcs.push(iframes[fi].src || '(no src)');
      }
      diagInfo.iframeSrcs = iframeSrcs;

      sendResponse(diagInfo);
      return;
    }
  });

  // ──────────────────────────────────────────────────────
  //  Auto-diagnostic on load
  // ──────────────────────────────────────────────────────
  var diag = getDiagnostics();
  console.log('[ANVISA Filler] ═══════════════════════════════════');
  console.log('[ANVISA Filler] Content script v1.1.0 loaded');
  console.log('[ANVISA Filler] URL:', diag.url);
  console.log('[ANVISA Filler] Frame:', diag.frame);
  console.log('[ANVISA Filler] DOM: Inputs=' + diag.inputs + ' Selects=' + diag.selects +
    ' Textareas=' + diag.textareas + ' Labels=' + diag.labels + ' Iframes=' + diag.iframes);
  console.log('[ANVISA Filler] Has patient section text:', diag.hasPacienteSection);
  console.log('[ANVISA Filler] ═══════════════════════════════════');

  // Delayed re-check after 5 seconds
  setTimeout(function () {
    var diag2 = getDiagnostics();
    console.log('[ANVISA Filler] After 5s: Inputs=' + diag2.inputs + ' Selects=' + diag2.selects +
      ' Textareas=' + diag2.textareas + ' Labels=' + diag2.labels);
    console.log('[ANVISA Filler] Has patient section text:', diag2.hasPacienteSection);

    if (!diag2.hasFormFields) {
      console.warn('[ANVISA Filler] ⚠ Formulário NÃO detectado nesta página.');
      console.warn('[ANVISA Filler] A extensão preencherá o formulário quando você clicar em "Preencher" no popup.');
      console.warn('[ANVISA Filler] Navegue até a página do formulário da ANVISA com os campos visíveis.');
    }
  }, 5000);
})();
