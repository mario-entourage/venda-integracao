/**
 * Content script injected on the ANVISA gov.br form page.
 * Receives 'fill-form' messages from the popup and fills form fields
 * using data stored in chrome.storage.local.
 *
 * Depends on: lib/field-mapping.js (FIELD_MAPPING, CASCADE_DEPENDENCIES, FILE_MAPPING)
 *             lib/brazilian-states.js (UF_MAP)
 *
 * KEY DESIGN DECISIONS:
 *
 * 1. The ANVISA form is a React/Next.js app using the Brazil Design System (DS Gov).
 *    The DS Gov does NOT always use standard <label for="id"> + <input id="id"> patterns.
 *    Labels may be <label>, <span>, <p>, <div>, or <strong> elements.
 *    IDs are often auto-generated (e.g. "react-select-2-input") and not meaningful.
 *
 * 2. The form has TWO sections with overlapping field names:
 *      "DADOS DO SOLICITANTE" (requester) — first in DOM
 *      "DADOS DO PACIENTE"   (patient)   — second in DOM
 *    Fields like "Nome", "Data de Nascimento", "CEP", "E-mail" exist in BOTH.
 *
 * 3. Our approach: find ALL text nodes on the page that match our keywords,
 *    then locate the nearest input/select/textarea element. For patient fields,
 *    only match elements that appear AFTER the "DADOS DO PACIENTE" heading.
 *
 * 4. Custom dropdowns (DS Gov br-select, react-select) are handled by detecting
 *    the wrapper type and simulating clicks + filter typing.
 *
 * 5. Cascading dropdowns (state → city) are handled by filling parents first,
 *    then waiting for child options to populate via MutationObserver + polling.
 *
 * 6. File uploads are handled by fetching files from Firebase Storage via the
 *    background service worker and injecting them using DataTransfer + File API.
 *
 * 7. The script may be re-injected on demand via chrome.scripting.executeScript
 *    from the popup. Guard against duplicate listeners with a global flag.
 */
(function () {
  'use strict';

  // Prevent duplicate injection
  if (window.__anvisaFillerLoaded) {
    console.log('[ANVISA Filler] Already loaded, skipping re-initialization');
    return;
  }
  window.__anvisaFillerLoaded = true;

  // ──────────────────────────────────────────────────────
  //  DOM position utilities
  // ──────────────────────────────────────────────────────

  function isBefore(a, b) {
    return !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  // ──────────────────────────────────────────────────────
  //  Section boundary detection
  // ──────────────────────────────────────────────────────

  var _requesterHeading = null;
  var _patientHeading = null;
  var _nextSectionHeading = null;

  function findSectionBoundaries() {
    // Always re-scan (the form may have changed since last call)
    _requesterHeading = null;
    _patientHeading = null;
    _nextSectionHeading = null;

    var allElements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, legend, strong, span, p, div, label');
    var sectionHeadings = [];

    for (var i = 0; i < allElements.length; i++) {
      var el = allElements[i];
      var text = getDirectText(el).trim().toLowerCase();

      if (text.indexOf('dados do solicitante') !== -1) {
        _requesterHeading = el;
        console.log('[ANVISA Filler] Found "DADOS DO SOLICITANTE" heading:', el.tagName, el.className);
      }
      if (text.indexOf('dados do paciente') !== -1) {
        _patientHeading = el;
        console.log('[ANVISA Filler] Found "DADOS DO PACIENTE" heading:', el.tagName, el.className);
      }
      if (text.indexOf('dados do solicitante') !== -1 ||
          text.indexOf('dados do médico') !== -1 ||
          text.indexOf('dados do medico') !== -1 ||
          text.indexOf('dados da receita') !== -1 ||
          text.indexOf('dados do prescritor') !== -1 ||
          text.indexOf('informações do médico') !== -1 ||
          text.indexOf('prosseguir para passo') !== -1) {
        sectionHeadings.push(el);
      }
    }

    if (_patientHeading) {
      for (var j = 0; j < sectionHeadings.length; j++) {
        if (isBefore(_patientHeading, sectionHeadings[j])) {
          _nextSectionHeading = sectionHeadings[j];
          console.log('[ANVISA Filler] Next section after patient:', _nextSectionHeading.tagName, getDirectText(_nextSectionHeading).trim());
          break;
        }
      }
    }

    if (!_patientHeading) {
      console.warn('[ANVISA Filler] Could not find "DADOS DO PACIENTE" heading — will fill without section scoping');
    }
    if (!_requesterHeading) {
      console.warn('[ANVISA Filler] Could not find "DADOS DO SOLICITANTE" heading — requester fields will fill without section scoping');
    }
  }

  function isInRequesterSection(el) {
    if (!_requesterHeading) return true;

    var afterRequesterHeading = isBefore(_requesterHeading, el);
    if (!afterRequesterHeading) return false;

    if (_patientHeading) {
      return isBefore(el, _patientHeading);
    }

    return true;
  }

  function isInPatientSection(el) {
    if (!_patientHeading) return true;

    var afterPatientHeading = isBefore(_patientHeading, el);
    if (!afterPatientHeading) return false;

    if (_nextSectionHeading) {
      return isBefore(el, _nextSectionHeading);
    }

    return true;
  }

  function getDirectText(el) {
    var text = '';
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === Node.TEXT_NODE) {
        text += el.childNodes[i].textContent;
      }
    }
    return text;
  }

  // ──────────────────────────────────────────────────────
  //  Promise helper
  // ──────────────────────────────────────────────────────

  function delay(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  // ──────────────────────────────────────────────────────
  //  Custom dropdown type detection
  // ──────────────────────────────────────────────────────

  function detectDropdownType(element) {
    if (!element) return 'unknown';

    if (element.tagName === 'SELECT') return 'native';

    var brSelect = element.closest('.br-select');
    if (brSelect) return 'br-select';

    var reactContainer = element.closest('[class*="css-"]');
    if (reactContainer) {
      var combobox = reactContainer.querySelector('[role="combobox"]') || reactContainer.querySelector('input');
      if (combobox) return 'react-select';
    }

    if (element.getAttribute('role') === 'combobox' || element.closest('[role="combobox"]')) {
      return 'react-select';
    }

    var parent = element.parentElement;
    for (var i = 0; i < 5 && parent; i++) {
      if (parent.classList && (parent.classList.contains('br-select') || parent.classList.contains('br-input'))) {
        return 'br-select';
      }
      if (parent.querySelector('.br-list, [role="listbox"]')) {
        return 'br-select';
      }
      parent = parent.parentElement;
    }

    return 'unknown';
  }

  // ──────────────────────────────────────────────────────
  //  Shared option matcher (all dropdown types)
  // ──────────────────────────────────────────────────────

  function findMatchingOption(items, value) {
    if (!items || items.length === 0 || !value) return null;

    var valueLower = value.toLowerCase().trim();
    var fullStateName = (typeof UF_MAP !== 'undefined' && UF_MAP[value.toUpperCase()]) || '';
    var fullStateNameLower = fullStateName.toLowerCase();

    var bestMatch = null;
    var bestScore = Infinity;

    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var text = (item.textContent || '').toLowerCase().trim();
      var dataVal = (item.getAttribute('data-value') || item.value || '').toLowerCase().trim();

      if (dataVal === valueLower || text === valueLower) return item;
      if (fullStateNameLower && (text === fullStateNameLower || dataVal === fullStateNameLower)) return item;

      if (text.indexOf(valueLower) !== -1 || (fullStateNameLower && text.indexOf(fullStateNameLower) !== -1)) {
        if (text.length < bestScore) {
          bestScore = text.length;
          bestMatch = item;
        }
      }
    }

    return bestMatch;
  }

  // ──────────────────────────────────────────────────────
  //  Value setters (React/Angular compatible)
  // ──────────────────────────────────────────────────────

  function setInputValue(element, value, mapping) {
    if (!element || !value) return Promise.resolve(false);

    var tagName = element.tagName.toLowerCase();

    if (tagName === 'select') {
      return Promise.resolve(setNativeSelectValue(element, value));
    }

    if (tagName === 'textarea') {
      return Promise.resolve(setValueWithNativeSetter(element, value, window.HTMLTextAreaElement));
    }

    // Custom dropdown handling for select-type fields
    if (mapping && mapping.inputType === 'select') {
      var type = detectDropdownType(element);
      console.log('[ANVISA Filler] Dropdown type for', mapping.dataKey, ':', type);

      if (type === 'br-select') {
        var brContainer = element.closest('.br-select') || element.parentElement;
        return setBrSelectValue(brContainer, value);
      }
      if (type === 'react-select') {
        var rsContainer = element.closest('[class*="css-"]') || element.closest('[role="combobox"]') || element.parentElement;
        return setReactSelectValue(rsContainer, value);
      }
    }

    return Promise.resolve(setValueWithNativeSetter(element, value, window.HTMLInputElement));
  }

  function setValueWithNativeSetter(element, value, prototypeObj) {
    try {
      var nativeSetter = Object.getOwnPropertyDescriptor(prototypeObj.prototype, 'value');
      if (nativeSetter && nativeSetter.set) {
        nativeSetter.set.call(element, value);
      } else {
        element.value = value;
      }

      element.focus();
      element.dispatchEvent(new Event('focus', { bubbles: true }));
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      element.dispatchEvent(new Event('blur', { bubbles: true }));

      return true;
    } catch (e) {
      console.warn('[ANVISA Filler] Error setting value:', e);
      return false;
    }
  }

  function setNativeSelectValue(selectEl, value) {
    if (!selectEl || !value) return false;

    var options = selectEl.querySelectorAll('option');
    var found = findMatchingOption(options, value);

    if (found) {
      selectEl.value = found.value;
      selectEl.dispatchEvent(new Event('change', { bubbles: true }));
      selectEl.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }

    return false;
  }

  // ──────────────────────────────────────────────────────
  //  DS Gov br-select handler
  // ──────────────────────────────────────────────────────

  function setBrSelectValue(container, value) {
    if (!container) return Promise.resolve(false);

    return new Promise(function (resolve) {
      // Step 1: Click trigger to open the dropdown
      var trigger = container.querySelector('.br-input input[type="text"]') ||
                    container.querySelector('.br-input button') ||
                    container.querySelector('.br-input') ||
                    container.querySelector('button') ||
                    container.querySelector('input');

      if (trigger) {
        trigger.click();
        trigger.focus();
      }

      // Step 2: Wait for the list to appear
      setTimeout(function () {
        var list = container.querySelector('.br-list, [role="listbox"]');
        if (!list) {
          list = document.querySelector('.br-list:not([hidden])');
        }

        if (!list) {
          console.warn('[ANVISA Filler] br-select: list not found');
          var nativeSelect = container.querySelector('select');
          if (nativeSelect) {
            resolve(setNativeSelectValue(nativeSelect, value));
          } else {
            resolve(false);
          }
          return;
        }

        // Step 3: Filter input
        var filterInput = container.querySelector('input[type="text"]') ||
                          container.querySelector('input:not([type="hidden"])');
        if (filterInput) {
          setValueWithNativeSetter(filterInput, value, window.HTMLInputElement);
        }

        // Step 4: Wait for filter, then click matching option
        setTimeout(function () {
          var items = list.querySelectorAll('.br-item, [role="option"], li');
          var match = findMatchingOption(items, value);

          if (match) {
            match.click();
            console.log('[ANVISA Filler] br-select: selected "' + (match.textContent || '').trim() + '"');
            resolve(true);
          } else {
            console.warn('[ANVISA Filler] br-select: no matching option for "' + value + '"');
            resolve(false);
          }
        }, 250);
      }, 200);
    });
  }

  // ──────────────────────────────────────────────────────
  //  React-Select handler
  // ──────────────────────────────────────────────────────

  function setReactSelectValue(container, value) {
    if (!container) return Promise.resolve(false);

    return new Promise(function (resolve) {
      var control = container.querySelector('[class*="control"]') || container;
      control.click();

      var input = container.querySelector('input');
      if (input) {
        input.focus();
        setValueWithNativeSetter(input, value, window.HTMLInputElement);
      }

      setTimeout(function () {
        var menu = container.querySelector('[class*="menu"]') ||
                   document.querySelector('[class*="menu"][class*="css-"]');

        if (!menu) {
          console.warn('[ANVISA Filler] react-select: menu not found');
          resolve(false);
          return;
        }

        var options = menu.querySelectorAll('[class*="option"]');
        var match = findMatchingOption(options, value);

        if (match) {
          match.click();
          console.log('[ANVISA Filler] react-select: selected "' + (match.textContent || '').trim() + '"');
          resolve(true);
        } else {
          console.warn('[ANVISA Filler] react-select: no matching option for "' + value + '"');
          resolve(false);
        }
      }, 350);
    });
  }

  // ──────────────────────────────────────────────────────
  //  Element finders - Multi-strategy approach
  // ──────────────────────────────────────────────────────

  function getInputNear(textElement, inputType) {
    if (!textElement) return null;

    var selector = 'input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), select, textarea';
    if (inputType === 'select') {
      selector = 'select, [role="combobox"], .br-select input, [class*="css-"] input, input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"])';
    } else if (inputType === 'textarea') {
      selector = 'textarea';
    } else if (inputType === 'input') {
      selector = 'input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"])';
    }

    // Strategy 1: Standard <label for="id">
    if (textElement.tagName === 'LABEL' && textElement.htmlFor) {
      var el = document.getElementById(textElement.htmlFor);
      if (el) return el;
    }

    // Strategy 2: Input inside the text element
    var childInput = textElement.querySelector(selector);
    if (childInput) return childInput;

    // Strategy 3: Walk through next siblings
    var sib = textElement.nextElementSibling;
    for (var sibCount = 0; sib && sibCount < 5; sibCount++) {
      if (sib.matches && sib.matches(selector)) return sib;
      var sibInput = sib.querySelector(selector);
      if (sibInput) return sibInput;
      if (inputType === 'select') {
        if (sib.classList && (sib.classList.contains('br-select') || sib.classList.contains('br-input'))) return sib;
        var brSel = sib.querySelector('.br-select');
        if (brSel) return brSel;
      }
      sib = sib.nextElementSibling;
    }

    // Strategy 4: Walk UP the DOM tree (up to 8 levels)
    var ancestor = textElement.parentElement;
    for (var level = 0; ancestor && level < 8; level++) {
      var tag = ancestor.tagName.toLowerCase();
      if (tag === 'body' || tag === 'form' || tag === 'main') break;

      var allInputsInAncestor = ancestor.querySelectorAll(selector);
      if (allInputsInAncestor.length === 1) {
        return allInputsInAncestor[0];
      }
      if (allInputsInAncestor.length > 1) {
        for (var ai = 0; ai < allInputsInAncestor.length; ai++) {
          if (isBefore(textElement, allInputsInAncestor[ai])) {
            return allInputsInAncestor[ai];
          }
        }
      }

      var nextAncestorSib = ancestor.nextElementSibling;
      for (var ns = 0; nextAncestorSib && ns < 3; ns++) {
        if (nextAncestorSib.matches && nextAncestorSib.matches(selector)) return nextAncestorSib;
        var nasInput = nextAncestorSib.querySelector(selector);
        if (nasInput) return nasInput;
        nextAncestorSib = nextAncestorSib.nextElementSibling;
      }

      ancestor = ancestor.parentElement;
    }

    return null;
  }

  function findTextElements(keyword) {
    var results = [];
    var keywordLower = keyword.toLowerCase();

    var candidates = document.querySelectorAll('label, span, p, div, strong, legend, h1, h2, h3, h4, h5, h6, td, th, a');

    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      var text = (el.textContent || '').toLowerCase().trim();

      if (text.indexOf(keywordLower) !== -1 && text.length < 300) {
        results.push({ element: el, text: text, length: text.length });
      }
    }

    results.sort(function (a, b) { return a.length - b.length; });
    return results;
  }

  function getSectionChecker(mapping) {
    var section = mapping.section;
    if (section === 'patient') {
      return { needsBoundaries: true, check: function (el) { return !_patientHeading || isInPatientSection(el); } };
    }
    if (section === 'requester') {
      return { needsBoundaries: true, check: function (el) { return !_requesterHeading || isInRequesterSection(el); } };
    }
    return { needsBoundaries: false, check: function () { return true; } };
  }

  function findElement(mapping) {
    var sectionInfo = getSectionChecker(mapping);

    if (sectionInfo.needsBoundaries) {
      findSectionBoundaries();
    }

    // Strategy A: Label keyword matching
    for (var k = 0; k < mapping.labelKeywords.length; k++) {
      var keyword = mapping.labelKeywords[k];
      var textElements = findTextElements(keyword);

      for (var t = 0; t < textElements.length; t++) {
        var textEl = textElements[t].element;

        if (!sectionInfo.check(textEl)) continue;

        var inputEl = getInputNear(textEl, mapping.inputType);
        if (inputEl) {
          if (!sectionInfo.check(inputEl)) continue;

          console.log('[ANVISA Filler] Found', mapping.dataKey, 'via label "' + keyword + '"',
            '→', inputEl.tagName, inputEl.name || inputEl.id || inputEl.className || '(no name/id)');
          return inputEl;
        }
      }
    }

    // Strategy B: Attribute-based search
    var allInputs = document.querySelectorAll('input:not([type="hidden"]), select, textarea');

    for (var a = 0; a < mapping.inputKeywords.length; a++) {
      var attrKeyword = mapping.inputKeywords[a].toLowerCase();

      for (var i = 0; i < allInputs.length; i++) {
        var inp = allInputs[i];

        if (!sectionInfo.check(inp)) continue;

        var searchStr = [
          inp.name || '',
          inp.id || '',
          inp.placeholder || '',
          inp.getAttribute('aria-label') || '',
          inp.getAttribute('data-field') || '',
          inp.getAttribute('formcontrolname') || '',
        ].join(' ').toLowerCase();

        if (searchStr.indexOf(attrKeyword) !== -1) {
          console.log('[ANVISA Filler] Found', mapping.dataKey, 'via attr "' + attrKeyword + '"',
            '→', inp.tagName, inp.name || inp.id || '(no name/id)');
          return inp;
        }
      }
    }

    // Strategy C: Positional matching for section-scoped fields
    if (sectionInfo.needsBoundaries && (mapping.section === 'patient' ? _patientHeading : _requesterHeading)) {
      for (var lk = 0; lk < mapping.labelKeywords.length; lk++) {
        var kw = mapping.labelKeywords[lk].toLowerCase();
        var allCandidates = document.querySelectorAll('label, span, p, div, strong, legend');

        for (var c = 0; c < allCandidates.length; c++) {
          var cand = allCandidates[c];
          if (!sectionInfo.check(cand)) continue;

          var candText = (cand.textContent || '').toLowerCase().trim();
          var kwWords = kw.split(/\s+/);
          var allWordsMatch = kwWords.every(function (w) { return candText.indexOf(w) !== -1; });

          if (allWordsMatch && candText.length < 200) {
            var nearInput = getInputNear(cand, mapping.inputType);
            if (nearInput && sectionInfo.check(nearInput)) {
              console.log('[ANVISA Filler] Found', mapping.dataKey, 'via positional "' + kw + '"',
                '→', nearInput.tagName, nearInput.name || nearInput.id || '(no name/id)');
              return nearInput;
            }
          }
        }
      }
    }

    return null;
  }

  // ──────────────────────────────────────────────────────
  //  Cascade: wait for child dropdown options
  // ──────────────────────────────────────────────────────

  function waitForOptionsToPopulate(mapping) {
    return new Promise(function (resolve) {
      var maxWait = 8000;
      var checkInterval = 400;
      var elapsed = 0;
      var resolved = false;
      var observer = null;

      function finish() {
        if (resolved) return;
        resolved = true;
        if (observer) observer.disconnect();
        resolve();
      }

      function hasOptions() {
        var element = findElement(mapping);
        if (!element) return false;

        var type = detectDropdownType(element);

        if (type === 'native') {
          return element.querySelectorAll('option').length > 1;
        }
        if (type === 'br-select') {
          var container = element.closest('.br-select') || element.parentElement;
          if (container) {
            return container.querySelectorAll('.br-item, [role="option"]').length > 1;
          }
        }
        return false;
      }

      function check() {
        if (resolved) return;

        if (hasOptions()) {
          console.log('[ANVISA Filler] Cascade: options populated for', mapping.dataKey, 'after', elapsed + 'ms');
          finish();
          return;
        }

        elapsed += checkInterval;
        if (elapsed >= maxWait) {
          console.warn('[ANVISA Filler] Cascade: timeout waiting for', mapping.dataKey, 'options (' + maxWait + 'ms)');
          finish();
          return;
        }

        setTimeout(check, checkInterval);
      }

      // MutationObserver for faster detection
      var element = findElement(mapping);
      if (element) {
        var target = element.closest('.br-select') || element.closest('.form-group') || element.parentElement;
        if (target) {
          observer = new MutationObserver(function () {
            setTimeout(function () {
              if (hasOptions()) {
                console.log('[ANVISA Filler] Cascade: options detected via MutationObserver for', mapping.dataKey);
                finish();
              }
            }, 150);
          });
          observer.observe(target, { childList: true, subtree: true, attributes: true });
        }
      }

      check();
    });
  }

  // ──────────────────────────────────────────────────────
  //  File upload: find file input near label
  // ──────────────────────────────────────────────────────

  function findFileInput(fileMapping) {
    for (var k = 0; k < fileMapping.labelKeywords.length; k++) {
      var keyword = fileMapping.labelKeywords[k];
      var textElements = findTextElements(keyword);

      for (var t = 0; t < textElements.length; t++) {
        var textEl = textElements[t].element;
        var fileInput = findNearbyFileInput(textEl);
        if (fileInput) {
          console.log('[ANVISA Filler] Found file input for', fileMapping.docType, 'via "' + keyword + '"');
          return fileInput;
        }
      }
    }

    return null;
  }

  function findNearbyFileInput(textElement) {
    var ancestor = textElement;
    for (var level = 0; level < 10 && ancestor; level++) {
      var fileInputs = ancestor.querySelectorAll('input[type="file"]');
      if (fileInputs.length === 1) return fileInputs[0];
      if (fileInputs.length > 1) {
        for (var i = 0; i < fileInputs.length; i++) {
          if (isBefore(textElement, fileInputs[i])) return fileInputs[i];
        }
        return fileInputs[0];
      }
      ancestor = ancestor.parentElement;
    }
    return null;
  }

  // ──────────────────────────────────────────────────────
  //  File upload: fetch via background + inject
  // ──────────────────────────────────────────────────────

  function fetchFileViaBackground(url, fileName) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage(
          { action: 'fetch-file', url: url, fileName: fileName },
          function (response) {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (response && response.success) {
              resolve(response);
            } else {
              reject(new Error(response ? response.error : 'Sem resposta do background worker'));
            }
          }
        );
      } catch (e) {
        reject(e);
      }
    });
  }

  function injectFile(fileInput, fileData) {
    return fetch(fileData.data)
      .then(function (res) { return res.blob(); })
      .then(function (blob) {
        var file = new File([blob], fileData.fileName, {
          type: fileData.type || 'application/octet-stream',
          lastModified: Date.now(),
        });

        var dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;

        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        fileInput.dispatchEvent(new Event('input', { bubbles: true }));

        // Also fire drop event on nearest drop zone
        var dropZone = fileInput.closest('[class*="upload"], [class*="drop"], [class*="file"], .upload-area, .drop-zone');
        if (dropZone) {
          try {
            var dropEvent = new DragEvent('drop', {
              bubbles: true,
              cancelable: true,
              dataTransfer: dataTransfer,
            });
            dropZone.dispatchEvent(dropEvent);
          } catch (e) {
            console.warn('[ANVISA Filler] Drop event failed:', e.message);
          }
        }

        console.log('[ANVISA Filler] File injected:', fileData.fileName, '(' + file.size + ' bytes)');
        return true;
      })
      .catch(function (err) {
        console.error('[ANVISA Filler] File injection error:', err);
        return false;
      });
  }

  function injectMultipleFiles(fileInput, fileDataArray) {
    var promises = fileDataArray.map(function (fd) {
      return fetch(fd.data).then(function (res) { return res.blob(); }).then(function (blob) {
        return new File([blob], fd.fileName, {
          type: fd.type || 'application/octet-stream',
          lastModified: Date.now(),
        });
      });
    });

    return Promise.all(promises).then(function (files) {
      var dataTransfer = new DataTransfer();
      files.forEach(function (file) { dataTransfer.items.add(file); });
      fileInput.files = dataTransfer.files;

      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      fileInput.dispatchEvent(new Event('input', { bubbles: true }));

      console.log('[ANVISA Filler] Injected', files.length, 'files');
      return true;
    }).catch(function (err) {
      console.error('[ANVISA Filler] Multi-file injection error:', err);
      return false;
    });
  }

  // ──────────────────────────────────────────────────────
  //  Form fill orchestration (async, three-phase)
  // ──────────────────────────────────────────────────────

  function fillSingleField(mapping, data) {
    var value = data[mapping.dataKey];
    if (!value || (typeof value === 'string' && !value.trim())) {
      return Promise.resolve(null);
    }

    var element = findElement(mapping);
    if (!element) {
      return Promise.resolve({
        field: mapping.dataKey,
        status: 'not_found',
        reason: 'Campo não encontrado na página' + (mapping.section ? ' (seção: ' + mapping.section + ')' : ''),
      });
    }

    return setInputValue(element, typeof value === 'string' ? value.trim() : value, mapping)
      .then(function (success) {
        if (success) {
          return { field: mapping.dataKey, status: 'filled', value: typeof value === 'string' ? value.trim() : value };
        }
        return { field: mapping.dataKey, status: 'error', reason: 'Falha ao definir valor' };
      });
  }

  function fillForm(data) {
    var results = { filled: 0, total: 0, details: [] };

    if (typeof FIELD_MAPPING === 'undefined') {
      console.error('[ANVISA Filler] FIELD_MAPPING not loaded');
      return Promise.resolve(results);
    }

    _requesterHeading = null;
    _patientHeading = null;
    _nextSectionHeading = null;

    // Diagnostic logging
    var inputCount = document.querySelectorAll('input:not([type="hidden"])').length;
    var selectCount = document.querySelectorAll('select').length;
    var textareaCount = document.querySelectorAll('textarea').length;
    var labelCount = document.querySelectorAll('label').length;

    console.log('[ANVISA Filler] ────────────────────────────────────');
    console.log('[ANVISA Filler] Starting fill with', Object.keys(data).length, 'data fields');
    console.log('[ANVISA Filler] Page has', inputCount, 'inputs,', selectCount, 'selects,',
      textareaCount, 'textareas,', labelCount, 'labels');

    var labels = document.querySelectorAll('label');
    for (var li = 0; li < Math.min(labels.length, 30); li++) {
      console.log('[ANVISA Filler]   Label[' + li + ']: "' +
        (labels[li].textContent || '').trim().substring(0, 100) + '"' +
        (labels[li].htmlFor ? ' (for=' + labels[li].htmlFor + ')' : ''));
    }

    var visInputs = document.querySelectorAll('input:not([type="hidden"])');
    for (var vi = 0; vi < Math.min(visInputs.length, 30); vi++) {
      console.log('[ANVISA Filler]   Input[' + vi + ']:',
        visInputs[vi].type || 'text',
        'name=' + (visInputs[vi].name || '(none)'),
        'id=' + (visInputs[vi].id || '(none)'),
        'placeholder=' + (visInputs[vi].placeholder || '(none)'));
    }

    var iframes = document.querySelectorAll('iframe');
    if (iframes.length > 0) {
      console.log('[ANVISA Filler] Page has', iframes.length, 'iframes:');
      for (var fi = 0; fi < iframes.length; fi++) {
        console.log('[ANVISA Filler]   iframe[' + fi + ']:', iframes[fi].src || '(no src)');
      }
    }

    var fileInputs = document.querySelectorAll('input[type="file"]');
    if (fileInputs.length > 0) {
      console.log('[ANVISA Filler] Page has', fileInputs.length, 'file input(s)');
    }

    console.log('[ANVISA Filler] ────────────────────────────────────');

    // Classify fields into phases
    var cascadeDeps = (typeof CASCADE_DEPENDENCIES !== 'undefined') ? CASCADE_DEPENDENCIES : {};
    var parentFields = [];
    var independentFields = [];
    var childFields = [];

    for (var i = 0; i < FIELD_MAPPING.length; i++) {
      var mapping = FIELD_MAPPING[i];
      var value = data[mapping.dataKey];
      if (!value || (typeof value === 'string' && !value.trim())) continue;

      results.total++;

      if (cascadeDeps[mapping.dataKey]) {
        childFields.push(mapping);
      } else if (mapping.cascadeChild) {
        parentFields.push(mapping);
      } else {
        independentFields.push(mapping);
      }
    }

    // Phase 1: Independent fields + cascade parents (sequential to preserve DOM state)
    var phase1 = independentFields.concat(parentFields);

    function processPhase1(idx) {
      if (idx >= phase1.length) return Promise.resolve();
      return fillSingleField(phase1[idx], data).then(function (result) {
        if (result) {
          results.details.push(result);
          if (result.status === 'filled') results.filled++;
        }
        return processPhase1(idx + 1);
      });
    }

    return processPhase1(0)
      .then(function () {
        if (childFields.length === 0) return;

        console.log('[ANVISA Filler] Phase 2: waiting for', childFields.length, 'cascade child dropdown(s)...');

        function processChild(idx) {
          if (idx >= childFields.length) return Promise.resolve();

          var childMapping = childFields[idx];
          console.log('[ANVISA Filler] Waiting for options:', childMapping.dataKey, '(parent:', cascadeDeps[childMapping.dataKey], ')');

          return waitForOptionsToPopulate(childMapping)
            .then(function () { return delay(200); })
            .then(function () { return fillSingleField(childMapping, data); })
            .then(function (result) {
              if (result) {
                results.details.push(result);
                if (result.status === 'filled') results.filled++;
              }
              return processChild(idx + 1);
            });
        }

        return processChild(0);
      })
      .then(function () {
        // Phase 3: File uploads
        var fileMapping = (typeof FILE_MAPPING !== 'undefined') ? FILE_MAPPING : [];
        var files = data._files;
        if (!files || !Array.isArray(files) || files.length === 0 || fileMapping.length === 0) return;

        console.log('[ANVISA Filler] Phase 3: uploading', files.length, 'file(s)...');

        function processFileType(idx) {
          if (idx >= fileMapping.length) return Promise.resolve();

          var fMap = fileMapping[idx];
          var matchingFiles = files.filter(function (f) { return f.docType === fMap.docType; });

          if (matchingFiles.length === 0) return processFileType(idx + 1);

          results.total++;

          var fInput = findFileInput(fMap);
          if (!fInput) {
            results.details.push({
              field: fMap.docType,
              status: 'not_found',
              reason: 'Campo de upload não encontrado na página',
            });
            return processFileType(idx + 1);
          }

          // Fetch all matching files via background worker
          var fetchPromises = matchingFiles.map(function (entry) {
            return fetchFileViaBackground(entry.downloadUrl, entry.fileName)
              .catch(function (err) {
                console.error('[ANVISA Filler] Failed to fetch:', entry.fileName, err);
                return null;
              });
          });

          return Promise.all(fetchPromises).then(function (fileDataArray) {
            var validFiles = fileDataArray.filter(function (fd) { return fd !== null; });

            if (validFiles.length === 0) {
              results.details.push({
                field: fMap.docType,
                status: 'error',
                reason: 'Falha ao baixar arquivo(s)',
              });
              return processFileType(idx + 1);
            }

            var injectPromise = validFiles.length === 1
              ? injectFile(fInput, validFiles[0])
              : injectMultipleFiles(fInput, validFiles);

            return injectPromise.then(function (success) {
              if (success) {
                results.filled++;
                results.details.push({
                  field: fMap.docType,
                  status: 'filled',
                  value: matchingFiles.map(function (f) { return f.fileName; }).join(', '),
                });
              } else {
                results.details.push({
                  field: fMap.docType,
                  status: 'error',
                  reason: 'Falha ao injetar arquivo no campo',
                });
              }
              return processFileType(idx + 1);
            });
          });
        }

        return processFileType(0);
      })
      .then(function () {
        return results;
      });
  }

  // ──────────────────────────────────────────────────────
  //  Wait for form to render (React/SPA)
  // ──────────────────────────────────────────────────────

  function waitForForm(callback) {
    var MAX_WAIT_MS = 15000;
    var CHECK_INTERVAL_MS = 500;
    var elapsed = 0;

    function check() {
      var inputCount = document.querySelectorAll('input:not([type="hidden"])').length;
      var selectCount = document.querySelectorAll('select').length;
      var textareaCount = document.querySelectorAll('textarea').length;
      var total = inputCount + selectCount + textareaCount;

      console.log('[ANVISA Filler] Waiting for form... ' + (elapsed / 1000) + 's | Total form elements:', total);

      if (total >= 3) {
        console.log('[ANVISA Filler] Form detected with', total, 'elements. Proceeding to fill.');
        setTimeout(callback, 300);
        return;
      }

      elapsed += CHECK_INTERVAL_MS;
      if (elapsed >= MAX_WAIT_MS) {
        console.warn('[ANVISA Filler] Timeout waiting for form. Elements found:', total);
        callback();
        return;
      }

      setTimeout(check, CHECK_INTERVAL_MS);
    }

    check();
  }

  // ──────────────────────────────────────────────────────
  //  Page diagnostic helper
  // ──────────────────────────────────────────────────────

  function getDiagnostics() {
    var inputCount = document.querySelectorAll('input:not([type="hidden"])').length;
    var selectCount = document.querySelectorAll('select').length;
    var textareaCount = document.querySelectorAll('textarea').length;
    var labelCount = document.querySelectorAll('label').length;
    var iframeCount = document.querySelectorAll('iframe').length;
    var fileInputCount = document.querySelectorAll('input[type="file"]').length;
    var total = inputCount + selectCount + textareaCount;

    var bodyText = (document.body.textContent || '').toLowerCase();
    var hasPaciente = bodyText.indexOf('dados do paciente') !== -1;
    var hasSolicitante = bodyText.indexOf('dados do solicitante') !== -1;
    var hasNomeCompleto = bodyText.indexOf('nome completo') !== -1;

    var brSelectCount = document.querySelectorAll('.br-select').length;
    var reactSelectCount = document.querySelectorAll('[class*="css-"][class*="container"]').length;

    return {
      url: window.location.href,
      frame: window === window.top ? 'TOP' : 'IFRAME',
      inputs: inputCount,
      selects: selectCount,
      textareas: textareaCount,
      labels: labelCount,
      iframes: iframeCount,
      fileInputs: fileInputCount,
      brSelects: brSelectCount,
      reactSelects: reactSelectCount,
      totalFormElements: total,
      hasFormFields: total >= 3,
      hasPacienteSection: hasPaciente,
      hasSolicitanteSection: hasSolicitante,
      hasNomeCompleto: hasNomeCompleto,
    };
  }

  // ──────────────────────────────────────────────────────
  //  Message listener
  // ──────────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === 'fill-form') {
      chrome.storage.local.get(['anvisaFormData'], function (result) {
        var data = result.anvisaFormData;

        if (!data) {
          sendResponse({
            success: false,
            error: 'Nenhum dado encontrado. Envie os dados do aplicativo primeiro.',
          });
          return;
        }

        waitForForm(function () {
          fillForm(data).then(function (fillResult) {
            console.log('[ANVISA Filler] Fill complete:', fillResult.filled, '/', fillResult.total, 'fields');

            sendResponse({
              success: true,
              filled: fillResult.filled,
              total: fillResult.total,
              details: fillResult.details,
            });
          }).catch(function (err) {
            console.error('[ANVISA Filler] Fill error:', err);
            sendResponse({
              success: false,
              error: 'Erro durante preenchimento: ' + err.message,
            });
          });
        });
      });

      return true; // Async response
    }

    if (message.action === 'check-page') {
      sendResponse(getDiagnostics());
      return;
    }

    if (message.action === 'diagnose') {
      var diagInfo = getDiagnostics();
      console.log('[ANVISA Filler] Diagnostics:', JSON.stringify(diagInfo, null, 2));

      var labels = document.querySelectorAll('label');
      var labelTexts = [];
      for (var i = 0; i < Math.min(labels.length, 30); i++) {
        labelTexts.push((labels[i].textContent || '').trim().substring(0, 80));
      }
      diagInfo.labelTexts = labelTexts;

      var iframes = document.querySelectorAll('iframe');
      var iframeSrcs = [];
      for (var fi = 0; fi < iframes.length; fi++) {
        iframeSrcs.push(iframes[fi].src || '(no src)');
      }
      diagInfo.iframeSrcs = iframeSrcs;

      sendResponse(diagInfo);
      return;
    }
  });

  // ──────────────────────────────────────────────────────
  //  Auto-diagnostic on load
  // ──────────────────────────────────────────────────────
  var diag = getDiagnostics();
  console.log('[ANVISA Filler] ═══════════════════════════════════');
  console.log('[ANVISA Filler] Content script v1.3.0 loaded');
  console.log('[ANVISA Filler] URL:', diag.url);
  console.log('[ANVISA Filler] Frame:', diag.frame);
  console.log('[ANVISA Filler] DOM: Inputs=' + diag.inputs + ' Selects=' + diag.selects +
    ' Textareas=' + diag.textareas + ' Labels=' + diag.labels + ' Iframes=' + diag.iframes +
    ' FileInputs=' + diag.fileInputs + ' BrSelects=' + diag.brSelects + ' ReactSelects=' + diag.reactSelects);
  console.log('[ANVISA Filler] Has patient section text:', diag.hasPacienteSection);
  console.log('[ANVISA Filler] ═══════════════════════════════════');

  setTimeout(function () {
    var diag2 = getDiagnostics();
    console.log('[ANVISA Filler] After 5s: Inputs=' + diag2.inputs + ' Selects=' + diag2.selects +
      ' Textareas=' + diag2.textareas + ' Labels=' + diag2.labels +
      ' FileInputs=' + diag2.fileInputs + ' BrSelects=' + diag2.brSelects);
    console.log('[ANVISA Filler] Has patient section text:', diag2.hasPacienteSection);

    if (!diag2.hasFormFields) {
      console.warn('[ANVISA Filler] Formulário NÃO detectado nesta página.');
      console.warn('[ANVISA Filler] A extensão preencherá o formulário quando você clicar em "Preencher" no popup.');
      console.warn('[ANVISA Filler] Navegue até a página do formulário da ANVISA com os campos visíveis.');
    }
  }, 5000);
})();
