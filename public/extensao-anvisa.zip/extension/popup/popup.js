/**
 * Extension popup script.
 * Manages popup UI state, displays stored data status,
 * and triggers form filling on the active ANVISA tab.
 */
(function () {
  'use strict';

  // Match any servicos.gov.br subdomain — the form may be on different subdomains
  var ANVISA_DOMAIN = 'solicitacao.servicos.gov.br';
  var ANVISA_DOMAIN_ALT = 'servicos.gov.br';

  var fieldLabels = {
    // Requester (solicitante) fields
    requesterRg: 'RG do Solicitante',
    requesterAddress: 'Endereço do Solicitante',
    requesterCep: 'CEP do Solicitante',
    requesterPhone: 'Celular do Solicitante',
    requesterLandline: 'Tel. Fixo do Solicitante',
    // Patient fields
    patientName: 'Nome do Paciente',
    patientRg: 'RG do Paciente',
    patientCpf: 'CPF do Paciente',
    patientDob: 'Data de Nascimento',
    patientCep: 'CEP do Paciente',
    patientAddress: 'Endereço do Paciente',
    patientState: 'Estado do Paciente',
    patientCity: 'Município do Paciente',
    patientPhone: 'Celular do Paciente',
    patientEmail: 'E-mail do Paciente',
    // Doctor/Prescription fields
    doctorName: 'Nome do Prescritor',
    doctorCrm: 'Nº do CRM/CRO',
    doctorSpecialty: 'Especialidade',
    doctorUf: 'Estado do Prescritor',
    doctorCity: 'Município do Prescritor',
    doctorPhone: 'Tel. Fixo do Prescritor',
    doctorMobile: 'Celular do Prescritor',
    doctorEmail: 'E-mail para Contato',
    prescriptionDate: 'Data da Receita',
  };

  // DOM Elements
  var statusDot = document.getElementById('status-dot');
  var statusText = document.getElementById('status-text');
  var patientNameEl = document.getElementById('patient-name');
  var fieldCountEl = document.getElementById('field-count');
  var timestampEl = document.getElementById('timestamp');
  var fillButton = document.getElementById('fill-button');
  var fillButtonText = document.getElementById('fill-button-text');
  var resultSection = document.getElementById('result-section');
  var resultIcon = document.getElementById('result-icon');
  var resultText = document.getElementById('result-text');
  var resultDetails = document.getElementById('result-details');
  var clearButton = document.getElementById('clear-button');
  var warningNotAnvisa = document.getElementById('warning-not-anvisa');

  var isOnAnvisaPage = false;
  var currentTabId = null;

  /**
   * Format a relative timestamp string.
   */
  function formatTimestamp(ts) {
    if (!ts) return '';

    var diff = Date.now() - ts;
    var seconds = Math.floor(diff / 1000);
    var minutes = Math.floor(seconds / 60);
    var hours = Math.floor(minutes / 60);

    if (seconds < 60) return 'Dados recebidos agora';
    if (minutes < 60) return 'Dados recebidos há ' + minutes + ' min';
    if (hours < 24) return 'Dados recebidos há ' + hours + 'h';
    return 'Dados recebidos há mais de 24h';
  }

  /**
   * Count filled fields in the data object.
   */
  function countFilledFields(data) {
    var total = Object.keys(fieldLabels).length;
    var filled = 0;

    for (var key in fieldLabels) {
      if (data[key] && data[key].trim()) {
        filled++;
      }
    }

    return { filled: filled, total: total };
  }

  /**
   * Update the UI based on stored data and current tab.
   */
  function updateUI() {
    chrome.storage.local.get(['anvisaFormData', 'dataTimestamp'], function (result) {
      var data = result.anvisaFormData;
      var timestamp = result.dataTimestamp;

      if (data && typeof data === 'object') {
        var counts = countFilledFields(data);

        statusDot.className = 'status-dot ready';
        statusText.textContent = 'Dados prontos';
        patientNameEl.textContent = data.patientName || 'Paciente não identificado';
        fieldCountEl.textContent = counts.filled + ' de ' + counts.total + ' campos com dados';
        timestampEl.textContent = formatTimestamp(timestamp);

        patientNameEl.classList.remove('hidden');
        fieldCountEl.classList.remove('hidden');
        timestampEl.classList.remove('hidden');

        // Enable fill button only if on ANVISA page
        if (isOnAnvisaPage) {
          fillButton.disabled = false;
          warningNotAnvisa.classList.add('hidden');
        } else {
          fillButton.disabled = true;
          warningNotAnvisa.classList.remove('hidden');
        }
      } else {
        statusDot.className = 'status-dot no-data';
        statusText.textContent = 'Nenhum dado';
        patientNameEl.textContent = '';
        fieldCountEl.textContent = 'Envie os dados pelo aplicativo web';
        timestampEl.textContent = '';

        patientNameEl.classList.add('hidden');
        timestampEl.classList.add('hidden');

        fillButton.disabled = true;
        warningNotAnvisa.classList.add('hidden');
      }
    });
  }

  /**
   * Check if the current active tab is on the ANVISA domain.
   */
  function checkCurrentTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs.length > 0 && tabs[0].url) {
        currentTabId = tabs[0].id;
        try {
          var url = new URL(tabs[0].url);
          isOnAnvisaPage = url.hostname === ANVISA_DOMAIN ||
            url.hostname.endsWith('.' + ANVISA_DOMAIN) ||
            url.hostname.endsWith('.' + ANVISA_DOMAIN_ALT) ||
            url.hostname === ANVISA_DOMAIN_ALT;
        } catch (e) {
          isOnAnvisaPage = false;
        }
      } else {
        isOnAnvisaPage = false;
      }
      updateUI();
    });
  }

  /**
   * Inject content scripts on demand using chrome.scripting.executeScript.
   * First resets the duplicate-injection guard, then injects the scripts.
   */
  function injectContentScripts(tabId, callback) {
    // First, reset the __anvisaFillerLoaded flag so the filler can re-register listeners
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId, allFrames: true },
        func: function () {
          window.__anvisaFillerLoaded = false;
        },
      },
      function () {
        // Now inject the actual scripts
        chrome.scripting.executeScript(
          {
            target: { tabId: tabId, allFrames: true },
            files: ['lib/brazilian-states.js', 'lib/field-mapping.js', 'content/anvisa-filler.js'],
          },
          function () {
            if (chrome.runtime.lastError) {
              console.warn('Script injection warning:', chrome.runtime.lastError.message);
            }
            // Small delay for scripts to initialize
            setTimeout(callback, 300);
          }
        );
      }
    );
  }

  /**
   * Handle the fill button click.
   * Strategy: try sending message to existing content script first.
   * If that fails (no content script listening), inject and retry.
   */
  function handleFill() {
    if (!currentTabId || !isOnAnvisaPage) return;

    fillButton.disabled = true;
    fillButtonText.textContent = 'Preenchendo...';
    resultSection.classList.add('hidden');

    // Try sending message directly first (content script may already be loaded)
    chrome.tabs.sendMessage(
      currentTabId,
      { action: 'fill-form' },
      function (response) {
        if (chrome.runtime.lastError || !response) {
          // Content script not responding — inject and retry
          console.log('Content script not responding, injecting...');
          injectContentScripts(currentTabId, function () {
            chrome.tabs.sendMessage(
              currentTabId,
              { action: 'fill-form' },
              function (response2) {
                handleFillResponse(response2);
              }
            );
          });
        } else {
          handleFillResponse(response);
        }
      }
    );
  }

  /**
   * Process the fill response from the content script.
   */
  function handleFillResponse(response) {
    fillButton.disabled = false;
    fillButtonText.textContent = 'Preencher Formulário';

    if (!response) {
      showResult(
        false,
        'Sem resposta do formulário. Recarregue a página da ANVISA e tente novamente.',
        null
      );
      return;
    }

    if (response.success) {
      if (response.filled === 0 && response.total > 0) {
        // All fields failed — the form may not be visible
        showResult(
          false,
          '0 de ' + response.total + ' campos preenchidos. O formulário pode não estar visível na página.',
          response.details
        );
      } else {
        showResult(
          true,
          response.filled + ' de ' + response.total + ' campo(s) preenchido(s)',
          response.details
        );
      }
    } else {
      showResult(false, response.error || 'Erro desconhecido', null);
    }
  }

  /**
   * Show fill results.
   */
  function showResult(success, message, details) {
    resultSection.classList.remove('hidden');
    resultSection.className = 'result-section' + (success ? '' : ' error');
    resultIcon.textContent = success ? '✓' : '✗';
    resultText.textContent = message;

    if (details && details.length > 0) {
      resultDetails.classList.remove('hidden');
      resultDetails.innerHTML = '';

      details.forEach(function (detail) {
        var div = document.createElement('div');
        div.className = 'detail-item ' + (detail.status === 'filled' ? 'detail-filled' : 'detail-missing');

        var icon = detail.status === 'filled' ? '✓' : '✗';
        var label = fieldLabels[detail.field] || detail.field;
        var info = detail.status === 'filled' ? '' : ' (' + (detail.reason || 'erro') + ')';

        div.textContent = icon + ' ' + label + info;
        resultDetails.appendChild(div);
      });
    } else {
      resultDetails.classList.add('hidden');
    }

    // If successful, briefly change button style
    if (success) {
      fillButton.classList.add('success');
      setTimeout(function () {
        fillButton.classList.remove('success');
      }, 3000);
    }
  }

  /**
   * Clear stored data.
   */
  function handleClear() {
    chrome.storage.local.remove(['anvisaFormData', 'dataTimestamp'], function () {
      chrome.runtime.sendMessage({ action: 'data-cleared' });
      resultSection.classList.add('hidden');
      updateUI();
    });
  }

  // Event listeners
  fillButton.addEventListener('click', handleFill);
  clearButton.addEventListener('click', handleClear);

  // Initialize
  checkCurrentTab();
})();
